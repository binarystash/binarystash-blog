<?php
/**
 * Plugin Name: WP Booklet 2
 * Description: Allows creation of flip books using the jQuery Booklet plugin. Successor to WP Booklet 1.x
 * Version: 2015.04.26
 * Author: BinaryStash
 * Author URI:  http://www.binarystash.net
 * License: GPLv2 (http://www.gnu.org/licenses/gpl-2.0.html)
 */
 
//Define constants
if(!defined('WP_BOOKLET2_URL')){
	define('WP_BOOKLET2_URL', plugin_dir_url(__FILE__) );
}

if(!defined('WP_BOOKLET2_DIR')){
	define('WP_BOOKLET2_DIR', realpath(plugin_dir_path(__FILE__)) . DIRECTORY_SEPARATOR );
}

//Include classes
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-booklet.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-page.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-command.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-controller.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-pdf.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-theme.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-theme-manager.php';
include WP_BOOKLET2_DIR . 'classes/class-wp-booklet2-importer.php';

//Initialize plugin
function wp_booklet2_instantiate() {
	new WP_Booklet2_Controller();
}

if ( get_bloginfo("version") >= 3.5 ) {
	//Initialize plugin only if Wordpress version >= 3.5
	add_action( 'plugins_loaded', 'wp_booklet2_instantiate', 15 );
}


