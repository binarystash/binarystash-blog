=== WP Booklet 2===
Contributors: binarystash01
Donate link: http://www.binarystash.com
Tags: flip book, flipbook, booklet
Requires at least: 3.5
Tested up to: 4.2
Stable tag: 2015.04.26
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows creation of flip books using the jQuery Booklet plugin

== Description ==

WP Booklet 2 makes creating brochures and magazine-like pages easily. It comes with built-in themes for casual users and allows more advanced users to add their own.

This plugin is the successor to WP Booklet 1.x and shares most of its features.

*   PDF uploads
*   Bulk image uploads
*   Page thumbnails
*   Compatibility with mobile devices
*	Full responsiveness
*	Bulk importer for WP Booklet 1.x booklets

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Create your flip books under 'Booklets 2'.
4. Copy the provided shortcode and paste it on pages or widgets.

== Frequently Asked Questions ==

= How do I change the style of my flip book? =

1. Under your theme folder, create a folder named `wpbooklet`.
2. Copy one of the provided themes under `/wp-content/plugins/wp-booklet2/themes/booklet` to `wpbooklet`. For example, `/wp-content/themes/my-theme/wpbooklet/light`.
3. Change the name of your custom theme. For example, `/wp-content/themes/my-theme/wpbooklet/light` to `/wp-content/themes/my-theme/wpbooklet/customtheme`.
4. Update the classes in `/wp-content/themes/my-theme/wpbooklet/customtheme/style.css` and `/wp-content/themes/my-theme/wpbooklet/booklet.php`.
5. Customize the look of your theme.
6. Your new theme should appear under themes menu.

= Do you provide flip book templates? = 

Yes. Two built-in themes are provided.

= How do I upload PDFs? =

Use the "Upload PDF" button beside the "Add pages" button. After upload, your PDF will be processed automatically.

= Why can't I see the "Upload PDF" button? =

WP Booklet relies on Ghostscript and Imagemagick for PDF conversion. If you can't see the button, then at least one of them is missing or misconfigured. If they are configured properly, you should see their versions under Booklet->Settings.

You also need to ensure that your uploads folder is writable by the web server. Check this status under Booklet->Settings.

If problems persist despite having proper configurations for the items above, please contact your web administrator or hosting provider.

= Why can't I convert more than 10 pages of my PDF? =

By default, WP Booklet only converts the first 10 pages of PDF files because PDF conversion can be extremely resource-intensive. You can disable this limit under WP Booklet->Settings.

= How do I upload images in bulk? =

On the media gallery popup, hold "CTRL" on your keyboard while selecting images.

== Changelog ==

= 2015.04.26 =
* Stable version

