<?php if ( $post->post_status == 'publish' ) : ?>
<p>Copy and paste the following shortcode to the page/post the booklet must appear on.</p>
<code class='wide'> [wp-booklet2 id=<?php echo $post->ID ?>]</code>
<?php else : ?>
<p>Publish this post to use the shortcode.</code>
<?php endif ?>