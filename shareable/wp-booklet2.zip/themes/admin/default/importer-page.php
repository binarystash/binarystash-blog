<div class="wrap">

	<h2>Importer</h2>
	
	<div class="importer-page-message updated success">
		<p><strong>Import successful.</strong></p>
	</div>
	<div class="importer-page-message updated error">
		<p><strong>Import unsuccessful. Please try again.</strong></p>
	</div>
	
	<p>Import your WP Booklet 1.x booklets to WP Booklet 2. Click the button below to get started. Please keep this page open until the process completes.</p>

	<form method="post" id="wp-booklet2-import-form">
		<table class="form-table">
		
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="wp-booklet-reimport">Re-import booklets</label></th>
					<td>
						<input type="checkbox" id="wp-booklet-reimport" name="wp-booklet-reimport"/>
						<label for="wp-booklet-reimport">Include previously imported booklets.</label>
						<p class="description">This creates new booklets. Previously imported booklets are not overwritten.</p>
					</td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="wp-booklet-reimport">Remaining booklets</label></th>
					<td>
						<span class="noreimport-count"><?php echo $remaining_booklets_noreimport ?></span>
						<span class="reimport-count"><?php echo $remaining_booklets_reimport ?></span>
					</td>
				</tr>
			</tbody>
			
		</table>
		<p class="submit">
			<input type="submit" class="button-primary" value="Import" />
		</p>
	</form>
	
</div>

<script type="text/javascript">
	jQuery(document).ready( function() {
		
		jQuery("#wp-booklet-reimport").change( function(e) {
			
			var target = jQuery(e.currentTarget);
			
			if ( target.is(":checked") ) {
				jQuery(".noreimport-count").hide();
				jQuery(".reimport-count").show();
			}
			else {
				jQuery(".noreimport-count").show();
				jQuery(".reimport-count").hide();
			}
			
		});
		
		jQuery("#wp-booklet2-import-form").submit( function(e) {
			
			e.preventDefault();
			
			jQuery("#wp-booklet2-import-form input").prop("disabled",true);
			jQuery(".importer-page-message").hide();
			
			do_import( jQuery("#wp-booklet-reimport").is(":checked"), 0);
			
			
		});
		
		function do_import(reimport,batch) {
			
			var data = {
				'reimport':reimport,
				'action':'import_booklets',
				'batch':batch
			};
			
			jQuery.post(ajaxurl,data,function(result) {
				
				jQuery(".reimport-count").text( result.remaining_reimport );
				jQuery(".noreimport-count").text( result.remaining_noreimport );
				
				if ( parseInt( result.remaining ) > 0 ) {
					setTimeout( function() {
						do_import(reimport, result.batch);
					},1);
				}
				else {
					jQuery("#wp-booklet2-import-form input").prop("disabled",false);
					jQuery(".importer-page-message.success").show();
				}
				
			},'json');
			
		}
		
	});
</script>